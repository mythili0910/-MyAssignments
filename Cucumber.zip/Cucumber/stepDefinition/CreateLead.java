package stepDefinition;
import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClass{

	@When("Click on the {string} link")
	public void click_on_the_link(String linktext) {
		driver.findElement(By.linkText(linktext)).click();
	}

	@When("Enter the Companyname as {string}")
	public void enter_the_companyname_as(String cname) {
	   driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		
	}
	@When("Enter the firstname as {string}")
	public void enter_the_firstname_as(String fname) {
	   driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		
	}
	@When("Enter the lastname as {string}")
	public void enter_the_lastname_as(String lname) {
	   driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		
	}
	@When("Enter phonenumber as {string}")
	public void enter_phonenumber_as(String phno) {
	   driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phno);
		
	}
	@When("Click on Create button")
	public void click_on_create_button() {
	   driver.findElement(By.name("submitButton")).click();
	}
	@Then("ViewLeadPage is created")
	public void view_lead_page_is_created() {
	   System.out.println(driver.getTitle());
	}
	}


