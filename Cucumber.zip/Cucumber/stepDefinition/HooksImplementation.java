package stepDefinition;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.testng.AbstractTestNGCucumberTests;

public class HooksImplementation extends BaseClass {

//	public ChromeDriver driver;
//	
//	@Before
//	public void preconditions() {
//		driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("http://leaftaps.com/opentaps/control/main/");
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));	
//	}
//	
//	@After
//	public void postconditions() {
//		driver.close();
//	}
}
