package stepDefinition;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;


public class DuplicateLead extends BaseClass {

	
	
	
	
		
	@Then ("ViewLeadsPage is displayed")
	public void viewleadspage_is_displayed() {
		String title=driver.findElement(By.xpath("//div[@id='sectionHeaderTitle_leads']")).getText();
		System.out.println(title);
	}
	
	
}
