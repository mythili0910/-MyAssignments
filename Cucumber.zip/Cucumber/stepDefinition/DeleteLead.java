package stepDefinition;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteLead extends BaseClass{

	@When("Enter the Phonenumber as {string}")
	public void enter_the_phonenumber_as(String phno) {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phno);
	    
	}
	@When("Click on Find Leads button")
	public void click_on_find_leads_button() throws Exception {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
	}
	@Then("Click on First lead record")
	public void click_on_first_lead_record() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
	}
	
	@Then("My LeadsPage is displayed")
	public void my_leads_page_is_displayed() {
		String title=driver.findElement(By.xpath("//div[@id='sectionHeaderTitle_leads']")).getText();
		System.out.println(title);
	}
}
