package stepDefinition;

import org.openqa.selenium.By;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Login extends BaseClass{

	@Given ("Enter username as {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
		
	}
	@Given ("Enter password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	@When("I Click on the login button")
	public void clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		
}
	@Then ("Welcome page is displayed")
	public void welcomePage() {
		System.out.println(driver.getTitle());
	}
	
	@But("Error message is displayed")
	public void verifyErrorMessage() {
		String str= driver.findElement(By.xpath("//p[text()='The Following Errors Occurred:']")).getText();
		System.out.println(str);
	}
	
	
	
//	@Then("Close browser")
//	public void close_browser() {
//		driver.close();
//	}
}
