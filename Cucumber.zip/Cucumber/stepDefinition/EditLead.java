package stepDefinition;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;

public class EditLead extends BaseClass{

	@Then("Edit the Companyname as {string}")
	public void edit_the_companyname_as(String cname) {
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(cname);
		
	}
			
	@Then("Click on Update button")
	public void click_on_update_button() {
	    driver.findElement(By.name("submitButton")).click();
	}
	
	
}
