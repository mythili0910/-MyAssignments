package runner;

//import org.testng.annotations.DataProvider;
import io.cucumber.testng.CucumberOptions;
import stepDefinition.BaseClass;

@CucumberOptions(features=".\\src\\test\\java\\feature",
				glue="stepDefinition", monochrome=true,publish=false)
				//tags="not@Sanity")
				//tags="@Sanity and @Smoke")
				//tags="@Sanity or @Smoke")
public class Runner extends BaseClass {

	
//	@DataProvider(parallel=false)
//	public Object[][] scenarios() {
//		// TODO Auto-generated method stub
//		return super.scenarios();
//	}
}
