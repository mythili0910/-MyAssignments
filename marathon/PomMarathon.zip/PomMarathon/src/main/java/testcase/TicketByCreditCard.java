package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.HomePage;

public class TicketByCreditCard extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues() {
		fileName="BookByCreditCard";
		sheetIndex=0;
		testName="TicketByCreditCard";
		testDesc="Book Movie Ticket with Card details";
		author="Mythili";
		category="Functional";
	}
	@Test (dataProvider="fetchData")
	public void bookTicket(String cityname,String cardNo,String expiryMMYY,String cvv,String name,String emailAddress,String phNo) throws IOException {
		
		try {
			new HomePage().searchCity(cityname).clickCity(cityname).clickMovie().verifySelectMovie()
			.selectDate().selectTimeslot().acceptTermsandConditions().chooseAvailableSeat().confirmBooking()
			.verifyBookingDetails().selectPaymentMethods().enterCardNumber(cardNo)
			.enterExpiry(expiryMMYY).enterCVV(cvv).enterName(name).enterPhoneNumber(phNo).verifyMakePayment();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		
		
		
		
	}
}
