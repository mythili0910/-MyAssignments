package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;

public class TicketByNetBanking extends ProjectSpecificMethod {
	@BeforeTest
	public void setValues() {
		fileName="BookByNetBanking";
		sheetIndex=0;
		testName="TicketByNetBanking";
		testDesc="Book Movie Ticket with NetBanking";
		author="Mythili";
		category="Functional";
	}
	@Test
	public void bookByNetBanking(String referenceNo) throws IOException {
		System.out.println("bookByNetBanking Testcase Invoked Successfully");
	}
}
