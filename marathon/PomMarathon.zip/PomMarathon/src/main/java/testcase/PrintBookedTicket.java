package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;

public class PrintBookedTicket extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues() {
		fileName="PrintTicket";
		sheetIndex=0;
		testName="PrintTicket";
		testDesc="Print Movie Ticket with Booking reference";
		author="Mythili";
		category="Regression";
	}
	@Test
	public void printTicket(String referenceNo) throws IOException {
		System.out.println("PrintTicket Testcase Invoked Successfully");
	}
}
