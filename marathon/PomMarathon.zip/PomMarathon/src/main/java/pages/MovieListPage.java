package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethod;

public class MovieListPage extends ProjectSpecificMethod{

	public MovieListPage clickMovie() {
		getDriver().findElement(By.xpath("//div[contains (@class,'poster')][1]")).click();
		return this;
	}
	public BookSlotPage verifySelectMovie() {
		WebElement movieName=getDriver().findElement(By.xpath("//div[@class='header']/h2"));
		if(movieName.isDisplayed()) {
		System.out.println("MovieName: "+movieName.getText());
		}
		else {
			System.out.println("MovieName is not visible ");
		}
		return new BookSlotPage();
	}
}
