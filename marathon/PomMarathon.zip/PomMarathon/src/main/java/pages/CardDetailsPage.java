package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethod;

public class CardDetailsPage extends ProjectSpecificMethod{
	
	public CardDetailsPage enterCardNumber(String cardNo) {
		getDriver().findElement(By.xpath("//div[@class='card']/input")).sendKeys("1234567890");
		return this;
	}
	public CardDetailsPage enterExpiry(String expiryMMYY) {
		getDriver().findElement(By.xpath("//label[text()='Expiry Date']/following::input")).sendKeys("08/29");
		return this;
	}
	public CardDetailsPage enterCVV(String cvv) {
		getDriver().findElement(By.xpath("//label[text()='CVV']/following::input")).sendKeys("987");
		return this;
	}
	public CardDetailsPage enterName(String name) {
		getDriver().findElement(By.xpath("//label[text()='Name']/following::input")).sendKeys("Arun");
		return this;
	}
	public CardDetailsPage enterEmail(String emailAddress) {
		getDriver().findElement(By.xpath("//input[@type='email']")).sendKeys("arun2334@gmail.com");
		return this;
	}	
	public CardDetailsPage enterPhoneNumber(String phNo) {
		getDriver().findElement(By.xpath("//span[text()='+91']/following::input")).sendKeys("9876543201");
		return this;
	}
	public CardDetailsPage verifyMakePayment() {
		
		WebElement makePaymentButton=getDriver().findElement(By.xpath("//span[text()='Enter Valid Card Number']"));
		System.out.println(makePaymentButton.getText());
		System.out.println("Payment cannot be made this time");
		return this;
	}
	
}
