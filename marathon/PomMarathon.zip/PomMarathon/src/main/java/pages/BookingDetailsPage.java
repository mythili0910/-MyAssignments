package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethod;

public class BookingDetailsPage extends ProjectSpecificMethod{

	public BookingDetailsPage verifyBookingDetails() {
		List<WebElement> ele=getDriver().findElements(By.xpath("//div[@class='box']"));
		//for (int i=0; i <= 2; i++){
		//build.moveToElement(ele.get(i)).perform();
		//System.out.println(ele.get(i).getText());
		//}
		System.out.println(ele.get(0).getText());
		System.out.println(ele.get(1).getText());
		System.out.println(ele.get(2).getText());
		return this;
	}
	public CardDetailsPage selectPaymentMethods() {
		getDriver().findElement(By.xpath("//div[text()='Pay with  Credit / Debit Card ']")).click();
		return new CardDetailsPage();
		
	}
}
