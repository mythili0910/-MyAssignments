package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import base.ProjectSpecificMethod;

public class SeatSelectionPage extends ProjectSpecificMethod {
	public Actions build = new Actions(getDriver());
	public SeatSelectionPage acceptTermsandConditions() {
		getDriver().findElement(By.xpath("//button[@class='swal2-confirm swal-confirm styled']")).click();
		return this;
	}
	
	public SeatSelectionPage chooseAvailableSeat() throws InterruptedException {
		

		WebElement seat1=getDriver().findElement(By.xpath("//div[text()='J09']"));
		WebElement seat2=getDriver().findElement(By.xpath("//div[text()='J08']"));
	
		Thread.sleep(5000);
		build.keyDown(Keys.CONTROL).click(seat1).click(seat2).keyUp(Keys.CONTROL).perform();
		
		return this;
	}
	
	public BookingDetailsPage confirmBooking() {
		
		getDriver().findElement(By.xpath("//div[@class='box progress enabled']/span")).click();
		return new BookingDetailsPage();
		
	}
}
