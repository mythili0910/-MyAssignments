package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod{

	public HomePage searchCity(String cityname) throws IOException 
	{
		try {
		getDriver().findElement(By.className("search")).sendKeys(cityname);
		reportStep("pass", "Cityname is entered Successfully ");
		}
		catch (Exception e){
			reportStep("fail", "Cityname is not entered Successfully ");
			System.out.println(e);
		}
		return this;
	}
	public MovieListPage clickCity(String cityname) {
		
		List<WebElement> city=getDriver().findElements(By.xpath("//div[@class='city shadow-small']"));
		
		for(int i=0;i<city.size();i++)
		{
			String cityName=city.get(i).getText();
			if(cityName.equalsIgnoreCase(cityname)){
				city.get(i).click();
				break;
			}
		}
		return new MovieListPage();
	}
	
}
