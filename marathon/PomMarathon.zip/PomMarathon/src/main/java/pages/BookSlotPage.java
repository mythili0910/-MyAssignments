package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethod;

public class BookSlotPage extends ProjectSpecificMethod{

	public BookSlotPage selectDate() {
		WebElement bookDay=getDriver().findElement(By.xpath("(//div[@class='date shadow-small undefined'][1]/span)[1]"));
		System.out.println("Booking Day "+bookDay.getText());
		
		WebElement bookDate=getDriver().findElement(By.xpath("(//div[@class='date shadow-small undefined'][1]/span)[2]"));
		System.out.println("Booking Date "+bookDate.getText());
	return this;
	}
	public SeatSelectionPage selectTimeslot() {
		WebElement bookTime=getDriver().findElement(By.xpath("//a[@class='schedule available'][1]"));
		System.out.println("Booking Time "+bookTime.getText());
		bookTime.click();
		
		return new SeatSelectionPage();
	}
}
