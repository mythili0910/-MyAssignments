package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	public static ChromeDriver driver;
	public static ChromeOptions ch=new ChromeOptions();
	public static Properties prop;
	public static ExtentReports extent;
	public static ExtentTest test,node;
	public String fileName;
	public int sheetIndex;
	public String testName,testDesc,author,category;
	
	private static final ThreadLocal<RemoteWebDriver> tldriver=new ThreadLocal<RemoteWebDriver>();
	
	
	public RemoteWebDriver getDriver() {
		return tldriver.get();
	}

	public void setDriver() {
		tldriver.set(new ChromeDriver());
	}
	


	//@Parameters ("language")
	@BeforeMethod 
	public  void preCondition() throws IOException {
		node=test.createNode(testName);
		//FileInputStream fis = new FileInputStream("./src/main/resources/" + language + ".properties");
		FileInputStream fis = new FileInputStream("./src/main/resources/English.properties");
		prop = new Properties();
		prop.load(fis);
		
		setDriver();
		ch.addArguments("--disable-notifications");
		getDriver().get("https://www.justickets.in/");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent=new ExtentReports();
		extent.attachReporter(reporter);
	}
	@BeforeClass
	public void testDetails() {
		test=extent.createTest(testName, testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}
	
	public void reportStep(String status, String message) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			node.pass(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		} else if (status.equalsIgnoreCase("fail")) {
			node.fail(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		}

	}
	

	public String takeSnap() throws IOException {
		String timestamp=new SimpleDateFormat("YYYYMMdd.HHmmss").format(new Date());
		File screenshotAs = getDriver().getScreenshotAs(OutputType.FILE);
		File destnfile = new File("./snap/shot" + timestamp + ".jpg");// empty
		FileUtils.copyFile(screenshotAs, destnfile);
		return timestamp;
	}
	
	@DataProvider(name="fetchData",indices = {0,2})//to choose the rows to be executed
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcel.readData(fileName);
		return data;
	}
	@AfterMethod 
	public  void postCondtition() {
		
		getDriver().close();
	}
	@AfterSuite
	public void endReport() {
		
		extent.flush();
	}

	
}
